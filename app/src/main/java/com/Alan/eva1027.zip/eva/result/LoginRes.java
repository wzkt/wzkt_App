package com.Alan.eva.result;

import com.Alan.eva.model.UserInfo;

/**
 * Created by CW on 2017/3/2.
 * 登录回调数据
 */
public class LoginRes extends Res{
    private UserInfo data;
    public UserInfo getData() {
        return data;
    }

}
