package com.Alan.eva.result;

/**
 * Created by CW on 2017/3/24.
 * 添加监护人返回结果
 */
public class AddMonitorRes extends Res {
    private String data;

    public String getData() {
        return data;
    }
}
