package com.Alan.eva.model.profile;

/**
 * Created by CW on 2017/4/10.
 * 孩子月统计平均值
 */
public class TempTrendItem {
    private int temp;
    private int day;

    public int getTemp() {
        return temp;
    }

    public int getDay() {
        return day;
    }
}
