package com.Alan.eva.result;

import com.Alan.eva.model.ChildModel;

import java.util.ArrayList;

/**
 * Created by CW on 2017/3/9.
 * 我的孩子结果
 */
public class ChildRes extends Res {
    private ArrayList<ChildModel> data;
    public ArrayList<ChildModel> getData() {
        return data;
    }
}
