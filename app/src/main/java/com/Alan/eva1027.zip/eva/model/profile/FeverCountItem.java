package com.Alan.eva.model.profile;

/**
 * Created by CW on 2017/4/11.
 * 发烧次数列表项
 */
public class FeverCountItem {
    private int count;
    private int day;

    public int getCount() {
        return count;
    }

    public int getDay() {
        return day;
    }
}
