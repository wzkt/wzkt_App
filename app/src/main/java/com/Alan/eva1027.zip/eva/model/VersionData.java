package com.Alan.eva.model;

/**
 * Created by CW on 2017/5/15.
 * 版本信息
 */
public class VersionData {
    private String vid;
    private String vCode;
    private String vName;
    private String path;
    private String newFeatures;

    public String getVid() {
        return vid;
    }

    public String getvCode() {
        return vCode;
    }

    public String getvName() {
        return vName;
    }

    public String getPath() {
        return path;
    }

    public String getNewFeatures() {
        return newFeatures;
    }
}
