package com.Alan.eva.result;

import com.Alan.eva.model.ChildSummary;

/**
 * Created by CW on 2017/4/20.
 * 孩子概况结果
 */
public class ChildSummaryRes extends Res {
    private ChildSummary data;

    public ChildSummary getData() {
        return data;
    }
}
