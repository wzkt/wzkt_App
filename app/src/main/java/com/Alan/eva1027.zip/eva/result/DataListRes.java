package com.Alan.eva.result;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by CW on 2017/5/4.
 * 异地监测结果
 */
public class DataListRes{

    public List<QueryDataRes> getHistorical_data() {
        return historical_data;
    }



    public List<QueryDataRes> historical_data;




}
