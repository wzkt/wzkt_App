package com.Alan.eva.result;

import com.Alan.eva.model.profile.MonthProfileData;

/**
 * Created by CW on 2017/4/10.
 * 孩子月统计数据
 */
public class MonthProfileRes extends Res {
    private MonthProfileData data;

    public MonthProfileData getData() {
        return data;
    }
}
