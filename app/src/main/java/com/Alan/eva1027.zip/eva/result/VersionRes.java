package com.Alan.eva.result;

import com.Alan.eva.model.VersionData;

/**
 * Created by CW on 2017/5/15.
 * 检查更新结果
 */
public class VersionRes extends Res {
    private VersionData data;

    public VersionData getData() {
        return data;
    }
}
