package com.Alan.eva.ui.widget;

/**
 * Created by CW on 2017/3/10.
 * 当滚轮控件被选中时
 */
interface OnWheelViewListener {
    void onSelected(int selectedIndex, String item);
}
