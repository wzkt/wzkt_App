package com.Alan.eva.tools.timer;

public interface ITimeFinish {

	/**
	 * 倒计时结束回调接口
	 */
	void onTimeFinish();
}
