package com.Alan.eva.model.profile;

/**
 * Created by CW on 2017/4/11.
 * 温度分布图数据
 */
public class TempRateData {
    private int normal;
    private int low;
    private int high;

    public int getNormal() {
        return normal;
    }

    public int getLow() {
        return low;
    }

    public int getHigh() {
        return high;
    }
}
