package com.Alan.eva.model;

/**
 * Created by CW on 2017/3/23.
 * 孩子监护人数据模型
 */
public class ChildMonitorData {
    private String bid;
    private String phone;

    public String getBid() {
        return bid;
    }

    public String getPhone() {
        return phone;
    }

    public void setBid(String bid) {
        this.bid = bid;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
